# -*- coding: utf-8 -*-
"""
Created on Mon Oct 14 11:59:57 2019

@author: Justus
"""
import WordEmbedObj
import matplotlib.pyplot as plt
import numpy as np

class BST(object):
    def __init__(self, data, left=None, right=None):  
        self.data = data
        self.left = left 
        self.right = right      
        
def Insert(T,newItem):
    if T == None:
        T =  BST(newItem)
    elif T.data.word >= newItem.word:
        T.left = Insert(T.left,newItem)
    else:
        T.right = Insert(T.right,newItem)
    return T
    
def Print(T):
    if T.left is not None:
        Print(T.left)
    print(T.data)
    if T.right is not None:
        Print(T.right)
        
def Min(T):
    a = T
    while a.left is not None:
        a = a.left
    return a

def Max(T):
    a = T
    while a.right is not None:
        a = a.right
    return a

def search(T, k):
    if T is None:
        return None   
    if T.data.word == k:
        return T.data
    elif k < T.data.word:             
        return search(T.left, k)        
    else:                 
        return search(T.right, k)
      
def size(T):
    counter = 1
    if T.left is not None:
        counter = counter + 1
        counter += size(T.left)      
    if T.right is not None:
        counter = counter + 1
        counter += size(T.right)  
    return counter     

def DepthOf(T,K):
    if T == None:
        return-1
    if T.data == K:
        return 0
    if K<T.data:
        d = DepthOf(T.left, K)
    else:
        d = DepthOf(T.right, K)
    if d == -1:
        return -1
    return d + 1
        
def height(T):
    if T == None:
        return 0
    lh = height(T.left)
    rh = height(T.right)
    return max([lh,rh]) + 1
               
def PrintDepth(T):
    Q = [T]
    while len(Q) > 0:
        front = Q.pop(0)
        if front != None:
            print(front.data)
            Q.append(front.left)
            Q.append(front.right)
            
