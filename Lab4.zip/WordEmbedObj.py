# -*- coding: utf-8 -*-
"""
Created on Mon Oct 14 10:09:00 2019

@author: Justus
"""
import numpy as np

class WordEmbedding(object):
    def __init__(self,word,embedding):
# word must be a string, embedding can be a list or and array of ints or floats
        self.word = word
        self.emb = np.array(embedding, dtype=np.float32) # For Lab 4, len(embedding=50)