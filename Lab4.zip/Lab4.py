# -*- coding: utf-8 -*-
"""
Created on Mon Oct 14 09:52:12 2019

@author: Justus
"""
import Lab4BST 
#import Lab4Btree
import time
import numpy as np
from WordEmbedObj import WordEmbedding



def readFile(Wordlist):
    f = open("glove.6B.50d.txt","r", encoding="utf8")
    temp = None
    for line in f:
        temp = line.split(" ")
        s = WordEmbedding(temp[0], temp[1:])
        Wordlist.append(s)
    f.close()
    return Wordlist

def readSimFile(referenceList):
    f = open("similarityList.txt","r", encoding="utf8")
    temp = None
    for line in f:
        line = line.strip()
        temp = line.split(" ")
        s = [temp[0], temp[1]]
        referenceList.append(s)
    f.close()
    return referenceList

def computeSim(firstWord, secondWord):
    dot = np.dot(firstWord, secondWord)
    normFirst = np.linalg.norm(firstWord)
    normSecond = np.linalg.norm(secondWord)
    sim = dot / (normFirst * normSecond)
    return sim



wordlist = []
referenceList = []
wordlist=readFile(wordlist)
referenceList=readSimFile(referenceList)
print("Choose table implementation")
print("Type 1 for binary search tree or 2 B-tree")
select = input("choice: ")
print()
BST = None
BT = None

if int(select) == 1:
    startTime = time.time()
    print("Building BST .....")
    print()
    for x in wordlist:       
        BST = Lab4BST.Insert(BST, x)
    print("Number of nodes: ", Lab4BST.size(BST))
    print("Height: ", Lab4BST.height(BST))
    endTime = time.time()
    runTime = endTime - startTime
    print("Running time for binary search tree construction: ", runTime)
    print()
    print("Determining similarities")
    print()
    print("Word similarities found:")
    startTime = time.time()
    for pair in referenceList:
        firstWord = Lab4BST.search(BST, pair[0])
        secondWord = Lab4BST.search(BST, pair[1])
        if firstWord is None or secondWord is None:
            continue
        sim = computeSim(firstWord.emb, secondWord.emb)
        print("Similarity [", pair[0] , "," , pair[1] , "] = ", sim)
    endTime = time.time()
    runTime = endTime - startTime
    print()
    print("Running time for binary search tree query processing: ", runTime)
        
        
#if select == 2:
#    MaxNumNode = input("Maximun number of items in node:")
#    print()
#    print("Building B-Tree .....")
#    for x in wordlist:
#        BT = Lab4Btree.BTree
#    print("Number of nodes: ")