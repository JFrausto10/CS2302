# -*- coding: utf-8 -*-
"""
Created on Mon Oct 14 15:37:57 2019

@author: Justus
"""
import Lab4BST
if('hello' == "hello"):
    print("yes")



