# -*- coding: utf-8 -*-
"""
Created on Wed Sep 25 09:56:25 2019

@author: Justus
"""
import math

class Node(object):
    # Constructor
    def __init__(self, data, next=None):  
        self.data = data
        self.next = next 
    
class sortedList(object):   
    # Constructor
    def __init__(self,head = None,tail = None):    
        self.head = head
        self.tail = tail
   
    def Print(self):
        t = self.head
        while t is not None:
            print(t.data,end=' ')
            t = t.next
        print()    
            
    def Append(self,i):
        if self.head is None:
            self.head = Node(i)
            self.tail = self.head
        else:
            self.tail.next = Node(i)
            self.tail = self.tail.next
            
    def insert(self, i):
        n = Node(i)
        if self.head == None:
            self.Append(i)
        elif(self.head.data >= n.data):
            n.next = self.head
            self.head = n
        else:
            t = self.head
            while t.next is not None and t.next.data < n.data:            
                   t = t.next
            n.next, t.next = t.next, n
  
    def delete(self,i):
            t = self.head
            while t.next is not None:
                if t.next.data == i:
                    t.next = t.next.next
                    break
                else:
                    t = t.next  
        
    def merge(self, M):
        if M.head == None:
            return
        if self.head == None:
            self.head = M.head
            self.tail = M.tail
        m = M.head
        while m is not None:
            self.insert(m.data)
            m = m.next
    
    def indexOf(self,i):
        t = self.head
        counter = 0
        while t is not None:
            if t.data == i:
                return counter
            counter += 1
            t = t.next
        return -1
    
    def clear(self):
        self.head = None
        self.tail = None
    
    def Min(self):
        if self.head == None:
            return -math.inf
        t = self.head
        Min = t.data
        while t.next is not None:
            if Min > t.data:
                Min = t.data
            t = t.next
        return Min
    
    def Max(self):
        if self.head == None:
            return -math.inf
        t = self.head
        Max = t.data
        while t is not None:
            if Max < t.data:
                Max = t.data
            t = t.next
        return Max
    
    def hasDuplicate(self):
        if self.head == None:
            return False
        t = self.head
        used = set()
        while t is not None:
            if t.data in used:
                return True
            used.add(t.data)
            t = t.next
        return False
            
        
        
                    