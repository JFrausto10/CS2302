# -*- coding: utf-8 -*-
"""
Created on Wed Sep 25 09:50:16 2019

@author: Justus
"""

from Lab3List import sortedList

if __name__ == "__main__": 
    print("Print")
    L1 = sortedList()
    print("No values")
    L1.Print()
    
    L1.insert(1)
    L1.insert(2)
    L1.insert(4)
    L1.insert(3)
    L1.insert(15)
    L1.insert(14)
    L1.insert(14)
    print("With Values")
    L1.Print()
    
    print("delete")
    L1.delete(14)
    L1.Print()
    
    print("index Of")
    Indexof = L1.indexOf(8)
    print(Indexof)
    
    print("min")
    Min = L1.Min()
    print(Min)
    
    print("max")
    Max = L1.Max()
    print(Max)
    
    print("Has Duplicates")
    L1.Print()
    dupe = L1.hasDuplicate()
    print(dupe)
    
#    print("clear")
#    L1.clear()
#    L1.Print()
#    print("end clear")
    
    print("Merge")
    L2 = sortedList()
    L2.insert(5)
    L2.insert(6)
    L2.insert(7)
    L2.insert(16)
    
    L2.Print()
    L1.merge(L2)
    L1.Print()