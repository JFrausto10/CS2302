# -*- coding: utf-8 -*-
"""
Created on Mon Nov 11 09:45:08 2019

@author: Justus
"""

import lab6AL
import lab6AM

def legalState(nextState):
    fox = nextState[0]
    chicken = nextState[1]
    grain = nextState[2]
    me = nextState[3]
    if  fox == chicken and not chicken == me:
        return False
    elif chicken == grain and not chicken == me:
        return False
    else:
        return True
    
def base10Conversion(States):
    baseTenStates = []
    for x in States:
        baseTenStates.append(int(x, 2))
    return baseTenStates

def nextValidState(currState, nextState):
    differences = 0     
    counter = 0
    for bit in currState:
        if bit != nextState[counter]:
            differences = differences + 1
        counter = counter + 1
    if differences > 2:
        return False
    else:
        return True
    
def createGraph(states, graph):
    for x in range(0 , len(states)):
        for y in range(x , len(states)):
            if x == y:
                continue    
            if  (nextValidState(states[x],states[y])) and (states[x][3] != states[y][3]):
                graph.insert_edge(int(states[x], 2), int(states[y], 2))
    
binaryList = []
for x in range(16):
    temp = '{0:b}'.format(x) 
    while(len(temp) < 4):
        temp = '0' + temp
    binaryList += [temp]
#print(binaryList)

legalStates = []
nonLegalStates = []

for x in binaryList:
    if legalState(x):
        legalStates += [x]
    else:
        nonLegalStates += [x]
print("All States")
print(binaryList)
print()
print("Legal States")
print(legalStates)
print() 
print("Non Legal States")
print(nonLegalStates)
print()
      
AL = lab6AL.Graph(len(legalStates)*len(legalStates))
createGraph(legalStates, AL) 
AM = lab6AM.Graph(len(legalStates)*len(legalStates))
createGraph(legalStates, AM) 
print()
print("AL Display")     
AL.display()
print()
print("AMasAL Display")
AMasAL = AM.as_AL()
print()
print("AM Display")    
AM.display()
print()
print("Breath First Search")
AL.bfs()
print()
print("Depth First Search")
AL.dfs()
        