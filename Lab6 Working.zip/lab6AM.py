import numpy as np
import matplotlib.pyplot as plt
import math
from scipy.interpolate import interp1d

class Graph:
    # Constructor
    def __init__(self, vertices, weighted=False, directed = False):
        self.am = np.zeros((vertices,vertices),dtype=int)-1
        self.weighted = weighted
        self.directed = directed
        self.representation = 'AM'
        
    def insert_edge(self,source,dest,weight=1):
        if self.directed == True:
            self.am[source][dest] = weight
        else:
            self.am[source][dest] = weight
            self.am[dest][source] = weight
        
        
    def delete_edge(self,source,dest):
        if self.directed == True:
            self.am[source][dest] = -1
        else:
            self.am[source][dest] = -1
            self.am[dest][source] = -1
        
                
    def display(self):
        print('\n', self.am)
     
    def draw(self):
        return 
    
    def as_EL(self):
        EL = []
        for x in range(len(self.am)):
            for y in range(len(self.am[0])):
                if self.am[y][x] == 1:
                    EL += [[x,y,1]]
        print('\n',EL)
    
    def as_AM(self):
        return self
    
    def as_AL(self):
        AL = []
        for x in range(len(self.am)-1):
            AL.append([])
        for x in range(len(self.am)):
            for y in range(len(self.am[x])):
                if self.am[y][x] == 1:
                    AL[y] +=([x,1])
        print('\n',AL)