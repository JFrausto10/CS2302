# Implementation of hash tables with chaining
# Programmed by Olac Fuentes
# Last modified October 27, 2019 by justus frausto

import time
import numpy as np
from WordEmbedObj import WordEmbedding

class HashTableChain(object):
    def __init__(self,size):  
        self.bucket = [[] for i in range(size)]
        
    def lenString(self, k):
        H = len(k) % len(self.bucket)
        return H
    
    def ordFChar(self, k):
        H = ord(k[0]) % len(self.bucket)
        return H
        
    def prodFandL(self, k):
        H = (ord(k[0]) * ord(k[-1])) % len(self.bucket)
        return H
    
    def sumAscii(self, k):
        Sum = 0
        for x in k:
            Sum += ord(x)
        H = Sum % len(self.bucket)
        return H
    
    def recurFormula(self, k, n):
        H = (ord(k[0]) + 255 * self.recurFormula(k[1:],n)) % len(self.bucket)
        return H
        
    def extraHashLastVal(self, k):
        H = ord(k[-1]) % len(self.bucket)
        return H
         
    
    def insert(self,k):
        b = self.lenString(k.word)           #### change insert method here
        if not k.word in self.bucket[b]:
            self.bucket[b].append(k)         
            
    def find(self,k):
        b = self.lenString(k.word[0])        #### change find method here
        try:
            i = self.bucket[b].index(k.word)
        except:
            i = -1
        return b, i
     
    def print_table(self):
        print('Table contents:')
        for b in self.bucket:
            print(b)
    
    def delete(self,k):
        b = self.h(k.word[0])
        try:
            self.bucket[b].remove(k)
            return 1
        except:
            return -1