# Implementation of hash tables with linear probing
# Programmed by Olac Fuentes
# Last modified October 27, 2019 by justus frausto

import numpy as np
import WordEmbedObj as WEO

class HashTableLP(object):
    # Builds a hash table of size 'size', initilizes items to -1 (which means empty)
    # Constructor
    def __init__(self,size):  
        self.item = [-1 for i in range(size)]
        
    def lenString(self, k):
        H = len(k)
        return H
    
    def ordFChar(self, k):
        H = ord(k[0])
        return H
        
    def prodFandL(self, k):
        H = (ord(k[0]) * ord(k[-1]))
        return H
    
    def sumAscii(self, k):
        Sum = 0
        for x in k:
            Sum += ord(x)
        H = Sum
        return H
    
    def recurFormula(self, k, n):
        H = (ord(k[0]) + 255 * self.recurFormula(k[1:],n))
        return H
        
    def extraHashLastVal(self, k):
        H = ord(k[-1])
        return H
        
    def insert(self,k):
        for i in range(len(self.item)): 
            pos = self.h(self.lenString(k.word)+i)
            if type(self.item[pos]) == WEO.WordEmbedding:
                continue
            if self.item[pos] < 0:
                self.item[pos] = k
                return pos
        return -1
    
    def find(self,k):
        for i in range(len(self.item)):
            pos = self.h(self.lenString(k.word)+i)
            if self.item[pos] == k:
                return pos
            if self.item[pos] == -1:
                return -1
        return -1
     
    def delete(self,k):
        f = self.find(k)
        if f >=0:
            self.item[f] = -2
        return f
    
    def h(self,k):
        return k%len(self.item)  
            
    
    def print_table(self):
        print('Table contents:')
        print(self.item)