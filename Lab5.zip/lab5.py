# -*- coding: utf-8 -*-
"""
Created on Sun Oct 24 12:48:29 2019

@author: jafraus
"""
import time
import numpy as np
from WordEmbedObj import WordEmbedding
from HashChain import HashTableChain
from HashLinearProbing import HashTableLP

def readFile(Wordlist):
    valid = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    valid = valid + ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
    f = open("glove.6B.50d.txt","r", encoding="utf8")
    temp = None
    for line in f:
        temp = line.split(" ")
        if(temp[0][0] not in valid):
            continue
        s = WordEmbedding(temp[0], temp[1:])
        Wordlist.append(s)
    f.close()
    return Wordlist

def readSimFile(referenceList):
    f = open("similarityList.txt","r", encoding="utf8")
    temp = None
    for line in f:
        line = line.strip()
        temp = line.split(" ")
        s = [temp[0], temp[1]]
        referenceList.append(s)
    f.close()
    return referenceList

def computeSim(firstWord, secondWord):
    dot = np.dot(firstWord, secondWord)
    normFirst = np.linalg.norm(firstWord)
    normSecond = np.linalg.norm(secondWord)
    sim = dot / (normFirst * normSecond)
    return sim


##########################  MAIN  ########################################
wordlist = []
referenceList = []
wordlist=readFile(wordlist)
referenceList=readSimFile(referenceList)
print("Choose the hash implementation")
print("Type 1 for chaining or 2 for linear probeing")
select = input("choice: ")
print()

if int(select) == 1:
    startTime = time.time()
    print("Building Hash Table With Chaining .....")
    print()
    HashC = HashTableChain(60)
    count = 0
    for x in wordlist:
        print(x.word)
        print(count)
        count += 1
        HashC.insert(x)
    print("done")
    endTime = time.time()
    print(endTime - startTime)
    startTime = time.time()
    for pair in referenceList:
        firstWord = HashTableChain.find(HashC, pair[0])
        secondWord = HashTableChain.find(HashC, pair[1])
        if firstWord is None or secondWord is None:
            continue
        sim = computeSim(firstWord.emb, secondWord.emb)
        print("Similarity [", pair[0] , "," , pair[1] , "] = ", sim)
    endTime = time.time()
    print(endTime - startTime)
    
elif int(select) == 2:
    startTime = time.time()
    print("Building Hash Table With Linear Probeing .....")
    print()
    HashL = HashTableLP(len(wordlist))
    count = 0
    for x in wordlist:
        print(x.word)
        print(count)
        count += 1
        HashL.insert(x)
        print("done")
    endTime = time.time()
    print(endTime - startTime)
    startTime = time.time()
    for pair in referenceList:
        firstWord = HashTableLP.find(HashL, pair[0])
        secondWord = HashTableLP.find(HashL, pair[1])
        if firstWord is None or secondWord is None:
            continue
        sim = computeSim(firstWord.emb, secondWord.emb)
        print("Similarity [", pair[0] , "," , pair[1] , "] = ", sim)
    endTime = time.time()
    print(endTime - startTime)